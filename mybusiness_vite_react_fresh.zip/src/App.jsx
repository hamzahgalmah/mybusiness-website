import React from 'react';

const App = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '2rem', color: '#6c5ce7' }}>
      <h1>Welcome to My Business Website</h1>
      <p>This is your starting point. Let's build something amazing.</p>
    </div>
  );
};

export default App;